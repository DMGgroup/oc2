# opencart-russia-language-2x
Русский язык для Opencart 2x Русская сборка  
http://opencart-russia.ru

ВНИМАНИЕ! 
Данный перевод разрешается использовать только в оригинальном OpenСart и в Русской сборке от opencart-russia.ru

