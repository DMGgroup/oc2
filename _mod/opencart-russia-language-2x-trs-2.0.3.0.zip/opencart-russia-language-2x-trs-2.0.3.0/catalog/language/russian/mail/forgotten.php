<?php
// Text
$_['text_subject']  = '%s - Новый пароль';
$_['text_greeting'] = 'Вами был запрошен новый пароль в %s.';
$_['text_password'] = 'Ваш новый пароль:';
