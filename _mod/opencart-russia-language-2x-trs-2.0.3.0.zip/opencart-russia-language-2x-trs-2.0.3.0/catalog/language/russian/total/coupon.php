<?php
// Text
$_['text_coupon'] = 'Купон (%s)';

