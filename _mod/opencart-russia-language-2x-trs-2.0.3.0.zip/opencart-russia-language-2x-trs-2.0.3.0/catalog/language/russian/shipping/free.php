<?php
// Text
$_['text_title']       = 'Бесплатная доставка';
$_['text_description'] = 'Бесплатная доставка';

