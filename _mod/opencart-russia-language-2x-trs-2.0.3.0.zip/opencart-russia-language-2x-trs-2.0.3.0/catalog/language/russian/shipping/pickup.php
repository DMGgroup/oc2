<?php
// Text
$_['text_title']       = 'Самовывоз';
$_['text_description'] = 'Самовывоз из магазина';

