<?php
// Heading
$_['heading_title']     = 'Клиенты онлайн';

// Text
$_['text_list']         = 'Список онлайн клиентов';
$_['text_guest']        = 'Гость';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Клиент';
$_['column_url']        = 'Последняя просмотренная страница';
$_['column_referer']    = 'Реферал';
$_['column_date_added'] = 'Последний клик';
$_['column_action']     = 'Действие';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Клиент';

