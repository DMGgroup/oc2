<?php
// Heading
$_['heading_title'] = 'Заказов';

// Text
$_['text_view']     = 'подробнее...';

